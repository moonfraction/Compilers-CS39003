int pwr(int arg1, int arg2) {
    if(arg2==0 || arg1==1) return 1;

    int t = pwr(arg1, arg2/2);
    t*=t;
    if(arg2%2) t *= arg1;
    return t;
}

void mprn(int MEM[], int idx) {
    printf("+++ MEM[%d] set to %d\n",idx, MEM[idx]);
}

void eprn(int R[], int idx) {
    printf("+++ Standalone expression evaluates to %d\n", R[idx]);
}