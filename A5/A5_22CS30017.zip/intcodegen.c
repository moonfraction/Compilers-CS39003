#include <stdio.h>
#include "y.tab.c"
#include "lex.yy.c"

extern int yyparse();

symboltable findID(symboltable T, char* id) {
    node* p = T;
    while (p) {
        if(!strcmp(p->id, id)) return p;
        p = p->next;
    }
    return NULL;
}
symboltable insertID(symboltable T, char* id){
    node* temp = (node*)malloc(sizeof(node));
    temp->id = id;
    temp->idx = -1;
    temp->mem_idx = -1;
    temp->next = NULL;
    if(T == NULL){
        T = temp;
    }
    else{
        node* temp2 = T;
        while(temp2->next != NULL){
            temp2 = temp2->next;
        }
        temp2->next = temp;
    }
    return T;
}
void add_pointer(symboltable node, int mem_idx){
    node->mem_idx = mem_idx;
}



int get_empty_reg() {
    for (int i = 2; i < 12; i++) {
        if (reg_occ[i]==0) {
            return i;
        }
    }
    return -1;
}

void free_reg(int idx) {
    reg_occ[idx] = 0;
}

void set_reg(int idx, int value) {
    R[idx] = value;
    reg_occ[idx] = 1;
}

int get_reg(int idx) {
    return R[idx];
}

int get_empty_load_reg() {
    for (int i = 0; i < 2; i++) {
        if (reg_occ[i]==0) {
            return i;
        }
    }
    return -1;
}


int find_available_mem_idx() {
    return size+1;
}

void set_mem(int idx, int value) {
    if(idx==size+1) size++;
    MEM[idx] = value;
}

int get_mem(int mem_idx) {
    return MEM[mem_idx];
}


int get_mem_idx(char* id) {
    node* f = findID(st, id);

    if(f==NULL) {
        st = insertID(st, id);
        int available_mem_idx = find_available_mem_idx();
        set_mem(available_mem_idx, 0);
        add_pointer(findID(st, id), available_mem_idx);
        return available_mem_idx;
    }
    return f->mem_idx;
}


int perform_operation(int a, int b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        case '%': return a % b;
        case '^': return pow(a, b);
        default: return 0;
    }
}


opd execute(opd t1, opd t2, char op, int type) {
    if(t2->idx == 15 || t2->idx == -1) t2->idx = 11; 
    if(t1->idx == -1 ) t1->idx = 11;
    if(t1->value == -1) t1->value = 0;
    if(t2->value == -1) t2->value = 0;
    int result;
    int storage_idx;
    int use_new_storage = 1;

    if (type == 0) { // Register storage
        if (t1->type == REG && t1->idx != 0 && t1->idx != 1) {
            storage_idx = t1->idx;
            use_new_storage = 0;
        } else {
            storage_idx = get_empty_reg();
        }
    } else if (type == 2) { // Memory storage
        storage_idx = find_available_mem_idx();
    }

    if (t1->type != IMM) {
        // Free the register of t1 if it is a register
        if (t1->type == REG) {
            free_reg(t1->idx);
        }

        result = perform_operation(
            (t1->type == REG ? R[t1->idx] : MEM[t1->idx]),
            (t2->type == REG ? R[t2->idx] : (t2->type == mem ? MEM[t2->idx] : t2->value)),
            op
        );

        if (type == 0) { // Register storage
            if (use_new_storage) {
                printf("    R[%d] = ", storage_idx);
            } else {
                printf("    R[%d] = ", t1->idx);
            }
            if(op == '^'){
                printf("pwr(R[%d], ", t1->idx);
                if (t2->type == REG) {
                    free_reg(t2->idx);
                    printf("R[%d]);\n", t2->idx);
                } else if (t2->type == mem) {
                    printf("MEM[%d]);\n", t2->idx);
                } else {
                    printf("%d);\n", t2->value);
                }
            }
            else{
                printf("R[%d] %c ", t1->idx, op);
                if (t2->type == REG) {
                    free_reg(t2->idx);
                    printf("R[%d];\n", t2->idx);
                } else if (t2->type == mem) {
                    printf("MEM[%d];\n", t2->idx);
                } else {
                    printf("%d;\n", t2->value);
                }
            }
        } else { // Memory storage
            printf("    MEM[%d] = ", storage_idx);
            if(op == '^'){
                printf("pwr(MEM[%d], ", t1->idx);
                if (t2->type == REG) {
                    free_reg(t2->idx);
                    printf("R[%d]);\n", t2->idx);
                } else if (t2->type == mem) {
                    printf("MEM[%d]);\n", t2->idx);
                } else {
                    printf("%d);\n", t2->value);
                }
            }
            else{
                printf("MEM[%d] %c ", t1->idx, op);
                if (t2->type == REG) {
                    free_reg(t2->idx);
                    printf("R[%d];\n", t2->idx);
                } else if (t2->type == mem) {
                    printf("MEM[%d];\n", t2->idx);
                } else {
                    printf("%d;\n", t2->value);
                }
            }
        }

        set_reg(storage_idx, result);


        opd reg_node = (opd)(malloc(sizeof(Operand)));
        reg_node->type = REG;
        reg_node->idx = storage_idx;
        return reg_node;
    } 
    else if (t2->type != IMM) {
        result = perform_operation(
            t1->value,
            (t2->type == REG ? R[t2->idx] : MEM[t2->idx]),
            op
        );

        storage_idx = t2->idx;

        if (t2->type == REG) {
            free_reg(t2->idx);
            printf("    R[%d] = ", storage_idx);
            if(op == '^'){
                printf("pwr(%d, R[%d]);\n", t1->value, t2->idx);
            }
            else{
                printf("%d %c R[%d];\n", t1->value, op, t2->idx);
            }
        } else {
            printf("    MEM[%d] = ", storage_idx);
            if(op == '^'){
                printf("pwr(%d, MEM[%d]);\n", t1->value, t2->idx);
            }
            else{
                printf("%d %c MEM[%d];\n", t1->value, op, t2->idx);
            }
        }
        set_reg(storage_idx, result);

        opd reg_node = (opd)(malloc(sizeof(Operand)));
        reg_node->type = REG;
        reg_node->idx = storage_idx;
        return reg_node;
    }
    else{
        // Both are IMM, and type ==2, use R0 as storage
        if(type == 2){
            storage_idx = 0;
        }
        else{
            storage_idx = get_empty_reg();
        }
        result = perform_operation(t1->value, t2->value, op);
        printf("    R[%d] = ", storage_idx);
        if(op == '^'){
            printf("pwr(%d, %d);\n", t1->value, t2->value);
        }
        else{
            printf("%d %c %d;\n", t1->value, op, t2->value);
        }
        set_reg(storage_idx, result);

        if(type==2){
            int available_mem_idx = find_available_mem_idx();
            set_mem(available_mem_idx, result);
            printf("    MEM[%d] = R[%d];\n", available_mem_idx, storage_idx);
            free_reg(storage_idx);
            
        }
        opd reg_node = (opd)(malloc(sizeof(Operand)));
        reg_node->type = REG;
        reg_node->idx = storage_idx;
        return reg_node;
    }

}
int main(){
    printf("#include <stdio.h>\n");
    printf("#include <stdlib.h>\n");
    printf("#include \"aux.c\"\n");
    printf("\n");
    printf("int main ( )\n");
    printf("{\n");
    printf("    int R[12];\n");
    printf("    int MEM[65536];\n");
    printf("\n");

    yyparse();

    printf("    exit(0);\n");
    printf("}\n");
    
    return 0;
}

